<?php
    mysqli_close($conexao);
    echo "<p style='color:brown;'>Conexão à base de dados encerrada.</p>";
?>